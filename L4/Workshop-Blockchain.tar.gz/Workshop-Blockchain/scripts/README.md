# Contracts

This folder contains the scripts used to deploy the SmartContracts from [`../contracts`](../contracts)