The main.py file is our implementation of the process.

The 4 .keras files are models needed in main.py.

There's also the modified tutorial_adversial.ipynb, with which we trained the models.

The functions.py file contains functions used in main.py.