from functions import edge_process, controller_process, MiTM_process, edge_process_modified
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model

height, width, channels = 32, 32, 3

n = 100
action = None
real_labels = []
pred_labels = []
confidences = []

pred_labels2 = []
pred_labels3 = []
pred_labels4 = []


for i in range(n): 
    #sample, label = edge_process()
    p = 0.1
    sample, label = edge_process_modified(p) # image collection and (emulated object detection)
    
    real_labels.append(label)
    # transmission between edge node and controller is emulated
    
    sampleA = MiTM_process(sample, multiplier=0.05)

    fig, (ax1,ax2) = plt.subplots(1, 2, sharey=True)
    ax1.imshow(sample.reshape(height,width, channels))
    ax1.set_title("Original Image")
    ax2.imshow(sampleA.reshape(height,width, channels))
    ax2.set_title("Image with Adversary")
    plt.show()
    
    model = load_model("cifar10_model.keras")
    action, pred_label, confidence = controller_process(sampleA,model) # per veure la verdadera accuracy, posar sample en comptes de sampleA
    pred_labels.append(pred_label)
    confidences.append(confidence)
    
    
    # comment if only initial model needed
    # for all models
    model2 = load_model("cifar10_model_2.keras")
    model3 = load_model("cifar10_model_3.keras")
    model4 = load_model("cifar10_model_4.keras")
    
    action2, pred_label2, confidence2 = controller_process(sampleA,model2)
    pred_labels2.append(pred_label2)
    
    action3, pred_label3, confidence3 = controller_process(sampleA,model3)
    pred_labels3.append(pred_label3)
    
    action4, pred_label4, confidence4 = controller_process(sampleA,model4)
    pred_labels4.append(pred_label4)
    
    
    #prints the necessary action for the initial model guess
    #print(action)
   
    
def num_errors(real_labels,pred_labels,numModel):
    
    int_list = [arr.item() for arr in real_labels]   
    for i in range(len(int_list)):
        if int_list[i] < 2:
            int_list[i] = 0
        elif int_list[i] < 8:
            int_list[i] = 2
        else:
            int_list[i] = 1
    print(int_list)
    print(pred_labels)
    errors = 0
    for i in range(len(pred_labels)):
        if int_list[i] != pred_labels[i]:
            errors += 1
    
    print("errors "+numModel+": ")
    print(errors)   
    
num_errors(real_labels,pred_labels,"initialModel")
num_errors(real_labels,pred_labels2,"model with 0.005")
num_errors(real_labels,pred_labels3, "model with 0.01")
num_errors(real_labels,pred_labels4,"model with 0.05")
#print('mean confidence: '+str((sum(confidences)/len(confidences))))



