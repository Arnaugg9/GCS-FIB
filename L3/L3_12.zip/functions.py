import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras.datasets import cifar10
from random import randint
from random import random
import numpy as np
from tensorflow.keras.models import load_model

def edge_process():
    height, width, channels = 32, 32, 3
    
    (x_train, y_train), (x_test, y_test) = cifar10.load_data()
    x = np.concatenate((x_train, x_test), axis=0)
    y = np.concatenate((y_train, y_test), axis=0)
    
    x = x / 255
    x = x.reshape((-1, height, width, channels))
    
    rand_idx = randint(0,x.shape[0]-1)
    sample = x[rand_idx].reshape((1, height, width, channels))
    label = y[rand_idx]


    return (sample, label)

def edge_process_modified(p):
    height, width, channels = 32, 32, 3
    
    (x_train, y_train), (x_test, y_test) = cifar10.load_data()
    x = np.concatenate((x_train, x_test), axis=0)
    y = np.concatenate((y_train, y_test), axis=0)
    
    x = x / 255
    x = x.reshape((-1, height, width, channels))
    
    all_auth_posi = [i for i in range(len(y)) if y[i].item() < 2]
    all_non_auth_posi = [i for i in range(len(y)) if y[i].item() >= 8]
    
    
    rand_idx = None
    r = random()
    if r <= p:    
        rand_idx = all_auth_posi[randint(0,len(all_auth_posi)-1)]
    else:
        rand_idx = all_non_auth_posi[randint(0,len(all_non_auth_posi)-1)]
        
        
    sample = x[rand_idx].reshape((1, height, width, channels))
    label = y[rand_idx]


    return (sample, label)



def controller_process(sample, model):
    
    label_pred = model.predict(sample)
    predicted_label = np.argmax(label_pred, axis=1)[0]
    confidence = label_pred[0][predicted_label]


    trad = {0: 'auth', 1: 'nonauth', 2: 'animal'}
    
    action = {'auth': 'No action required', 'nonauth': "Block Aircraft Traffic & Activate Border Police Protocol Against Intrusions", 'animal': 'Warn Aircraft taking off and landing & Move Surveillance Team to the affected area'}
    
    return (action[trad[predicted_label]], predicted_label, confidence)


def generate_adversary(image):
    
    label = np.array([0.0, 1.0, 0.0], dtype=np.float32) # nonauth label
    
    image = tf.cast(image, tf.float32)
    with tf.GradientTape() as tape:
        tape.watch(image)
        model = load_model("cifar10_model.keras") # assumim que mitm te un model com el nostre
        prediction = model(image)

        loss = tf.keras.losses.MSE(label, prediction) # assumim que sempre tenim nonauth, ja que no tenim l'etiqueta real, i aixi intentara canviar els nonauth
    
    gradient = tape.gradient(loss, image)
    sign_grad = tf.sign(gradient)
    return sign_grad
    
def MiTM_process(sample, multiplier):
    
    perturbations = generate_adversary(sample).numpy()

    adversarial = sample + (perturbations * multiplier)
    adversarial = np.clip(adversarial, 0.0, 1.0)
    
    return adversarial







